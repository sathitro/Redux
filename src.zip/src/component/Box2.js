import React from 'react';

export default function Box1() {
    return (
        <div>
            <h2>Box2</h2>
        </div>
    )
}
